<nav class="gtco-nav" role="navigation">
	<div class="gtco-container">
		
		<div class="row">
			<div class="col-sm-4 col-xs-12">
				<div id="gtco-logo"><a href="index.php">Ch'Efrei <em>.</em></a></div>
			</div>
			<?php
			if(!isset($_SESSION['nom_utilis'])){
			?>
				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li class="btn-cta" data-toggle="modal"  data-dismiss="modal" data-target="#at-login"><a><span>Se connecter</span></a></li>
						<li class="btn-cta"><a href="signin.php"><span>S'inscrire</span></a></li>
					</ul>	
				</div>
			<?php
			}
			else{
				?>

				<div class="col-xs-8 text-right menu-1">
					<ul>
						<li class="has-dropdown">
							<a class="primary-color bold"><img src="images/icon-chef.png" alt="icon-chef" height="25" width="25"><?php echo ucwords(strtolower($_SESSION['prenom_utilis']))." ".ucwords(strtolower($_SESSION['nom_utilis']));?></a>
							<ul class="dropdown">
								<li><a href="mes-recettes.php">Mes recettes</a></li>
								<li><a href="mes-avis.php">Mes avis</a></li>
								<li><a href="index.php?disconnect=true">Se déconnecter</a></li>
							</ul>					
						</li>				
						
					</ul>
				</div>

				<?php
			}
			?>
		</div>			
	</div>
</nav>