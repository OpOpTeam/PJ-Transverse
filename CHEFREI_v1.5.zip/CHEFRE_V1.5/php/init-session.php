<?php

session_start();
if(isset($_GET['disconnect'])){
	unset($_SESSION['ID_utilis']);
	unset($_SESSION['nom_utilis']);
	unset($_SESSION['prenom_utilis']);
	unset($_SESSION['vegetarien']);
	unset($_SESSION['halal']);
	unset($_SESSION['vegan']);
   session_destroy();
   header("Location: index.php");
}

if(isset($_POST['submitted'])){
   $ad_mail = test_input($_POST['email']);
   $mot_d_passe = test_input($_POST['password']);
   if(connexion($ad_mail, $mot_d_passe) == true){
   		$_SESSION['ID_utilis'] = initialisationSession('ID_utilis',$ad_mail);   		
   		$_SESSION['nom_utilis'] = initialisationSession('nom_utilis',$ad_mail);
   		$_SESSION['prenom_utilis'] = initialisationSession('prenom_utilis',$ad_mail);
   		$_SESSION['vegetarien'] = initialisationSession('vegetarien',$ad_mail);
   		$_SESSION['halal'] = initialisationSession('halal',$ad_mail);
   		$_SESSION['vegan'] = initialisationSession('vegan',$ad_mail);
   		
   }
   else{
   	 	echo "<script language='javascript'>
               	alert('Email ou mot de passe incorrect');
            </script>";
   }
}

?>