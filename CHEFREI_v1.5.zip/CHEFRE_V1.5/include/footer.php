<footer id="gtco-footer" role="contentinfo" style="background-image: url(images/img_bg_3.jpg)" data-stellar-background-ratio="0.5">
	<div class="overlay"></div>
	<div class="gtco-container">
		<div class="row row-pb-md">			
			<div class="col-md-12 text-center">
				<div class="gtco-widget">
					<h3>Team OPOP</h3>
					
			<div class="col-md-12 text-center copyright">
				<p><small class="block">&copy; 2018</small> 
			</div>
		</div>
	</div>
</footer>