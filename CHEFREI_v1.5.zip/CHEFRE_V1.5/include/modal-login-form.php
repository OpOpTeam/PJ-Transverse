<section class="at-login-form">
	<!-- MODAL LOGIN -->
	<div class="modal fade" id="at-login" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<div class="row">
						<div class="col-md-6">
							<h3 class="cursive-font primary-color">Connexion</h3>
						</div>
						<div class="col-md-6">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
						</div>
					</div>
				</div>
				<div class="modal-body">
					<form method="post" action="<?php echo htmlspecialchars($_SERVER['REQUEST_URI']); ?>">
						<input type='hidden' name='submitted' id='submitted' value='1'/>
						<div class="form-group">
							<input type="email" class="form-control" id="exampleInputEmaillog" placeholder="Votre adresse email" name = "email" required>
						</div>
						<div class="form-group">
							<input type="password" class="form-control " id="exampleInputPasswordpas" placeholder="Mot de passe" name = "password" required>
						</div>
						<button type="submit" class="btn btn-primary" name = "login">Se connecter</button>
					</form>						
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-md-8 text-left">	
							<a href="signin.php" class="primary-color">Vous n'avez pas de compte ?</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>