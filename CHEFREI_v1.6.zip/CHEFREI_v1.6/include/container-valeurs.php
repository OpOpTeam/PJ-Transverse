<div id="gtco-features">
	<div class="gtco-container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
				<h2 class="cursive-font">Nos valeurs</h2>
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 col-sm-6">
				<div class="feature-center animate-box" data-animate-effect="fadeIn">
					<span class="icon">
						<i class="ti-face-smile"></i>
					</span>
					<h3>Ils se sont régalés !</h3>
					<p>Notre algorithme vous propose des recettes spécialement choisies pour vous.</p>
				</div>
			</div>
			<div class="col-md-6 col-sm-6">
				<div class="feature-center animate-box" data-animate-effect="fadeIn">
					<span class="icon">
						<i class="ti-comments-smiley"></i>
					</span>
					<h3>Ils ont donné leur avis !</h3>
					<p>Donner votre avis sur les recettes nous permet de vous proposer des recettes en adéquation avec votre profil !</p>
				</div>
			</div>
		</div>
	</div>
</div>