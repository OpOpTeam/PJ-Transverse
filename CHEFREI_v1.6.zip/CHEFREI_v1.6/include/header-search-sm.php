<header id="gtco-header" class="gtco-cover gtco-cover-sm" role="banner" style="background-image: url(images/img_bg_1.jpg)" data-stellar-background-ratio="0.5">
	<div class="overlay"></div>
	<div class="gtco-container">
		<br>
		<br>
		<div class="row">
			<div class="col-md-12 col-md-offset-0 text-left">	
				<div class="row row-mt-14em">
					<div class="col-md-12 mt-text animate-box" data-animate-effect="fadeInUp">
						<h1 class="cursive-font">Des recettes pour tous les goûts !</h1>	
					</div>
				</div>				
			</div>
		</div>
		<div class="row">
			<div class="col-md-6 animate-box" data-animate-effect="fadeIn">
				<div class="form-wrap">
					<div class="tab">							
						<div class="tab-content">
							<div class="tab-content-inner active">
								<h2 class="cursive-font">Chercher une recette</h2>
								<form method="GET" action="recherche.php">										
									<div class="row form-group">
										<div class="col-md-12">
											<input class="form-control" name="recette" id="recette" type="text" placeholder="Chercher : tarte, cookies, pizza">
										</div>
									</div>										
									<div class="row form-group">
										<div class="col-md-12">
											<input type="submit" class="btn btn-primary btn-block" value="Rechercher">
										</div>
									</div>
								</form>	
							</div>								
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6 animate-box" data-animate-effect="fadeIn">
				<div class="form-wrap">
					<div class="tab">							
						<div class="tab-content">
							<div class="tab-content-inner active">
								<h2 class="cursive-font">Chercher par ingrédient</h2>
								<form method="GET" action="recherche.php">
									<div class="row form-group">
										<div class="col-md-12">
											<input class="form-control" name="recherche_ingr" type="text" placeholder="Chercher : pomme, boeuf, fromage">
										</div>
									</div>									
									<div class="row form-group">
										<div class="col-md-12">
											<input type="submit" class="btn btn-primary btn-block" value="Rechercher">
										</div>
									</div>
								</form>	
							</div>								
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</header>