<?php
require_once("php/db-config.php");
require_once("php/login-check.php");
require_once("php/init-session.php");
?>


<!DOCTYPE HTML>
<!--
	Aesthetic by gettemplates.co
	Twitter: http://twitter.com/gettemplateco
	URL: http://gettemplates.co
-->
<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Ch'Efrei</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">


	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet">
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Themify Icons-->
	<link rel="stylesheet" href="css/themify-icons.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">

	<!-- Magnific Popup -->
	<link rel="stylesheet" href="css/magnific-popup.css">

	<!-- Bootstrap DateTimePicker -->
	<link rel="stylesheet" href="css/bootstrap-datetimepicker.min.css">

	<!-- Owl Carousel  -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">

	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/style2.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->

	</head>
	<body>
		
	<div class="gtco-loader"></div>
	
	<div id="page">

	
	<!-- <div class="page-inner"> -->
	<?php
		include ("include/navbar.php");
	?>

	<header id="gtco-header" class="gtco-cover gtco-cover-md" role="banner" style="background-image: url(images/img_bg_1.jpg)" data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container">
			<br>
			<br>
			<div class="row">
				<div class="col-md-12 col-md-offset-0 text-left">	
					<div class="row row-mt-14em">
						<div class="col-md-12 mt-text animate-box" data-animate-effect="fadeInUp">
							<h1 class="cursive-font text-center primary-color">Ch'Efrei</h1>
							<h1 class="cursive-font">Des recettes pour tous les goûts !</h1>	
						</div>
					</div>				
				</div>
			</div>
			<div class="row">
				<div class="col-md-6 animate-box" data-animate-effect="fadeInUp">
					<div class="form-wrap">
						<div class="tab">							
							<div class="tab-content">
								<div class="tab-content-inner active">
									<h2 class="cursive-font">Chercher une recette</h2>
									<form method="GET" action="recherche.php">										
										<div class="row form-group">
											<div class="col-md-12">
												<input class="form-control" name="recette" id="recette" type="text" placeholder="Chercher : tarte, cookies, pizza">
											</div>
										</div>										
										<div class="row form-group">
											<div class="col-md-12">
												<input type="submit" class="btn btn-primary btn-block" value="Rechercher">
											</div>
										</div>
									</form>	
								</div>								
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 animate-box" data-animate-effect="fadeInUp">
					<div class="form-wrap">
						<div class="tab">							
							<div class="tab-content">
								<div class="tab-content-inner active">
									<h2 class="cursive-font">Chercher par ingrédient</h2>
									<form method="GET" action="recherche.php">
										<div class="row form-group">
											<div class="col-md-12">
												<input class="form-control" name="recherche_ingr" type="text" placeholder="Chercher : pomme, boeuf, fromage">
											</div>
										</div>									
										<div class="row form-group">
											<div class="col-md-12">
												<input type="submit" class="btn btn-primary btn-block" value="Rechercher">
											</div>
										</div>
									</form>	
								</div>								
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>

	
	
	<div class="gtco-section">
		<div class="gtco-container">
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">Nos recettes populaires !</h2>
					<p>Ils ont adoré...</p>
				</div>
			</div>
			<div class="row">

				<?php
					affichage_meilleures_notes_global(dbLogin());
				?>				

			</div>
			<br>
			<hr>
			<br>
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">Nos nouveautés !</h2>
				</div>
			</div>
			<div class="row">

				<?php
					nouveaute_recette(dbLogin());
				?>				

			</div>
			<br>
			<hr>
			<br>
			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading">
					<h2 class="cursive-font primary-color">Les succès du moment !</h2>
				</div>
			</div>
			<div class="row">

				<?php
					nouveaute_les_mieux_note(dbLogin());
				?>				

			</div>
		</div>
	</div>
	
	<?php
		include ("include/container-valeurs.php");
	?>


	<div class="gtco-cover gtco-cover-sm" style="background-image: url(images/img_bg_2.jpg)"  data-stellar-background-ratio="0.5">
		<div class="overlay"></div>
		<div class="gtco-container text-center">
			<div class="display-t">
				<div class="display-tc">
					<h1>&ldquo; Une recette à mon image !&rdquo;</h1>
					<p>&mdash; Kinh Vinh TRAN</p>
				</div>	
			</div>
		</div>
	</div>

	<div id="gtco-counter" class="gtco-section">
		<div class="gtco-container">

			<div class="row">
				<div class="col-md-8 col-md-offset-2 text-center gtco-heading animate-box">
					<h2 class="cursive-font primary-color">Nos chiffres</h2>
				</div>
			</div>

			<div class="row">
				
				<?php affichage_chiffres(dbLogin());?>
					
			</div>
		</div>
	</div>

	<?php
		include ("include/footer.php");
	?>

	<?php
		include ("include/modal-login-form.php");
	?>

	</div>

	<div class="gototop js-top">
		<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>

	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>

	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	
	<script src="js/moment.min.js"></script>
	<script src="js/bootstrap-datetimepicker.min.js"></script>


	<!-- Main -->
	<script src="js/main.js"></script>

	</body>
	
</html>

